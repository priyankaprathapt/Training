package com.techprimers.ekskinesisexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EksKinesisExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
