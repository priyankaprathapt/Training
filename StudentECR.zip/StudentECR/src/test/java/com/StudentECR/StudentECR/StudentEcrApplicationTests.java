package com.StudentECR.StudentECR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentEcrApplicationTests {

	@Test
	void contextLoads() {
	}

}
